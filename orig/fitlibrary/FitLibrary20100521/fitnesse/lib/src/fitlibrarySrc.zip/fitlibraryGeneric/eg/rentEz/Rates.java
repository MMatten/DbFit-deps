package fitlibraryGeneric.eg.rentEz;

public class Rates {
	//
}
