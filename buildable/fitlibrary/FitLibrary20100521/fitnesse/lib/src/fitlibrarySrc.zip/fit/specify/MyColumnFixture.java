package fit.specify;

public class MyColumnFixture extends fit.ColumnFixture {
	public int x = 0;
	
	public int x() {
		return x;
	}
}