package fit.decorator.util;

public interface Timer {
  long elapsed();

  void start();
}
