package fitbook.chat;
/*
 * @author Rick Mugridge 18/04/2004
 * Copyright (c) 2004 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 */

/**
 *
 */
public class User {
	public String name;

	public User(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
}
