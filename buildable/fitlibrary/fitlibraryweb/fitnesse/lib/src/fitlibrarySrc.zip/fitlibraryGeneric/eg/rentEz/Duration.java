package fitlibraryGeneric.eg.rentEz;

public class Duration {
	//
}
