import fitlibrary.DoFixture;

public class SetUp extends DoFixture {
	public boolean testTwo() {
		return true;
	}
}
