/*
 * @author Rick Mugridge on Dec 31, 2004
 *
 * Copyright (c) 2004 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 *
 */

/**
 *
 */
public class TestCreditKorean extends fitlibrary.CalculateFixture {
    public String ampersandHash49888SemicolonAmpersandHash50857SemicolonAmpersandHash54728SemicolonAmpersandHash50857SemicolonAmpersandHash50900SemicolonAmpersandHash49888SemicolonAmpersandHash50857SemicolonAmpersandHash51088SemicolonAmpersandHash44201SemicolonAmpersandHash50976SemicolonAmpersandHash47924SemicolonAmpersandHash51092SemicolonAmpersandHash50529Semicolon(
            int months, String reliable, double balance) {
        return reliable;        
    }
    public double ampersandHash49888SemicolonAmpersandHash50857SemicolonAmpersandHash54620SemicolonAmpersandHash46020SemicolonAmpersandHash50529SemicolonAmpersandHash50900SemicolonAmpersandHash49888SemicolonAmpersandHash50857SemicolonAmpersandHash51088SemicolonAmpersandHash44201SemicolonAmpersandHash50976SemicolonAmpersandHash47924SemicolonAmpersandHash51092SemicolonAmpersandHash50529Semicolon(
            int months, String reliable, double balance) {
        return balance;
    }
}
