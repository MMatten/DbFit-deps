package fitlibrary.annotation;

public enum ActionType {
    SIMPLE, PREFIX, SUFFIX, SELF_FORMAT, IGNORE 
}