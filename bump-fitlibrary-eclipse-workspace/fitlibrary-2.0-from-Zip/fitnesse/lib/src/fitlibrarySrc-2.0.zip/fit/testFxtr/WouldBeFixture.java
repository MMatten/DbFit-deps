// Copyright (C) 2003-2009 by Object Mentor, Inc. All rights reserved.
// Released under the terms of the CPL Common Public License version 1.0.
package fit.testFxtr;

/**
 * This "fixture" intentionally does not extend a Fixture class.
 *
 * @author jbrains
 * @see HandleFixtureDoesNotExtendFixtureTest
 */
public class WouldBeFixture {
  public String go() {
    return "OK!";
  }
}
